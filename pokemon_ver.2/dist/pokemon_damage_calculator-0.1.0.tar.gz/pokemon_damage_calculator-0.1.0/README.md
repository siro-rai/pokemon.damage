# Pokémon Damage Calculator

A simple Pokémon damage calculator.

## Installation

You can install the package via pip:

```sh
pip install pokemon_damage_calculator
